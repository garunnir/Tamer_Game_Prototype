# Known Issues & Incomplete

## Inspector Setup Required (Manual)
- QuarterViewCamera._player must be assigned in Inspector
- PlayerController._cameraTransform must be assigned in Inspector
- FlockManager._playerTransform must be assigned in Inspector
- CombatSystem + ProjectilePool must each be on a GameObject in the scene

## Data
- Existing MonsterData .asset files do not have _attackCooldown set
  → Re-run WildTamer → Generate Monster Data Assets (or set via Inspector)

## Not Yet Implemented
- MonsterC — not yet implemented
- MonsterA — implemented; MonsterA.asset values (moveSpeed=4, attackRange=1.5) must be set manually in Inspector
- BossA / BossB
- TamingSystem
- HitEffect
- FogOfWar
- MinimapController
