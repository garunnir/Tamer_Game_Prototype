# Implementation Decisions

## Camera
- _basePosition tracks unshaken position so Lerp never reads shake-displaced value — prevents cumulative drift
- CameraShake uses Update-loop timer with linear magnitude decay — no coroutine per CLAUDE.md rules
- CameraShake accumulates via Mathf.Max — consecutive hits don't reset shake to zero
- Shake offset uses transform.right + transform.up (camera-local) not world XY — correct for 60deg pitch
- LateUpdate used (not Update) — camera moves after player Transform is updated

## Player
- Rigidbody.linearVelocity (Unity 6 API); preserves Y for gravity
- FreezeRotation constraint set in Awake — physics can't tip capsule; script controls rotation via RotateTowards
- Animator.StringToHash("Speed") cached as static readonly — no per-frame string allocation

## Flock System
- FlockManager uses single shared _nearbyBuffer (cleared per unit) — zero per-frame heap allocation
- _sqrDetectionRadius cached in Awake — skip sqrt in hot detection loop
- FlockUnit.VelocityDirection retains last valid direction when speed drops to zero — prevents zero-vector LookRotation crash
- FlockUnit._maxSpeed = 7f (> PlayerController._moveSpeed 5f) — units can catch up during sprint
- FlockUnit.CalculateTargetSeek uses distance-proportional strength (Clamp(dist/_maxSpeed, 0, 1.5)) — rubber-band effect
- AddUnit() captures newIndex before list.Add(), calls Recalculate after — array size always matches index
- FormationHelper is pure C# class (not MonoBehaviour) — FlockManager holds instance; no scene component needed

## Monster Data
- No MonsterType enum — MonsterData asset itself is the type identifier (asset name = ID)
- MonsterDataGenerator uses SerializedObject.FindProperty() to set private SerializeField fields — direct assignment after CreateAsset() does not serialize correctly

## Combat System
- CombatSystem.ScanTargets() via InvokeRepeating(0.2s) — never per frame
- GetNearestInRange seeds nearestSqrDist = source.DetectionRange² — no separate range filter step needed
- Combatants register in Start() not Awake() — CombatSystem singleton Instance guaranteed to exist first
- Dead combatants remain in list until OnDisable() fires — IsAlive check prevents targeting dead units
- Unregistration on death: EnterDead → OnDeath → SetActive(false) → OnDisable → UnregisterCombatant
- MonsterBase._sqrAttackRange cached in Awake — avoids per-frame multiply in hot loop
- MonsterBase.EnterAttack sets _attackTimer=0 — monster fires immediately on entering range (responsive feel)
- FlockUnitCombat SRP: FlockUnit owns movement, FlockUnitCombat owns HP/attack — separate components
- ProjectilePool.CreateFallbackPrefab adds Projectile component to primitive — no Inspector dependency needed
- MonsterBase.OnMonsterDied is static event — TamingSystem subscribes once, not per-monster
- MonsterBase patrol uses Random.insideUnitCircle (flat XZ) — monsters stay grounded without physics
- MoveToward ignores Y delta and normalises direction — monsters stay grounded

## MonsterA
- PerformAttack() virtual hook added to MonsterBase between UpdateAttack() and FireProjectile() — melee subclasses override it; ranged subclasses inherit the default (FireProjectile()); cooldown/range logic stays in one place
- MonsterA only overrides PerformAttack() — all state transitions, movement, detection, death are inherited; concrete class is required for component type identity and prefab assignment
- MonsterA inspector: _data → MonsterA.asset; moveSpeed=4, attackRange=1.5, detectionRange=8 (set manually after generating assets via WildTamer menu)

## MonsterB
- _sqrAttackRange is private in MonsterBase — MonsterB caches its own _mySqrAttackRange in Awake() using _data.AttackRange; no MonsterBase change needed
- Retreat uses dynamic retreatPoint = transform.position - toTarget.normalized * (retreatDistance * 2) — recalculated each frame so monster always flees directly away even if target moves
- Zigzag anchor is _currentTarget.Transform.position (not monster position) — offset oscillates around the target so approach is net-convergent; monster always closes distance on average
- PerformAttack() calls EnterChase() mid-UpdateAttack() — harmless: the _attackTimer assignment after return is irrelevant because EnterAttack() resets timer to 0 on next entry
- _zigzagTimer reset in EnterChase() override — clean wave start each time approach begins, avoids mid-cycle continuation artifacts
- MonsterB inspector: _data → MonsterB.asset; moveSpeed=7, attackRange=4, detectionRange=10; _zigzagAmplitude must remain < attackRange (default 3 < 4)
