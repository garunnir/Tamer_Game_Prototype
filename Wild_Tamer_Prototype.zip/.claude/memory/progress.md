# Progress & Checklist

## Implementation Checklist
- [x] Project setup / quarter-view camera
- [x] Player movement
- [x] FlockUnit.cs
- [x] FlockManager.cs
- [x] FormationHelper.cs
- [x] MonsterData.cs + assets
- [x] ICombatant.cs
- [x] CombatSystem.cs
- [x] Projectile.cs + ProjectilePool.cs
- [x] FlockUnitCombat.cs
- [x] MonsterBase.cs
- [x] Normal monster A (melee)
- [x] Normal monster B (ranged + zigzag + retreat)
- [ ] Normal monster C (fast/swarmer)
- [ ] Boss A (AoE slam)
- [ ] Boss B (charge)
- [ ] TamingSystem.cs
- [ ] Hit feedback (hitstop, hitlag, camera shake, hit flash)
- [ ] Fog of War
- [ ] Minimap
- [ ] Bestiary UI (bonus)
- [ ] Data persistence save/load (bonus)

## Last Session
- MonsterB.cs (zigzag projectile + retreat) (2026-03-02)

## Completed Work Summary
- QuarterViewCamera.cs: fixed quarter-view follow camera with smooth lerp and CameraShake() hook
- PlayerController.cs: Rigidbody-based WASD movement with camera-relative direction and Animator Speed hook
- FlockUnit.cs: Transform-based unit with separation/alignment/cohesion/target-seek; VelocityDirection property for alignment reads
- FlockManager.cs: singleton; drives neighbor detection via sqrMagnitude loop; dispatches UpdateUnit(); AddUnit()/RemoveUnit() public API; delegates formation offset to FormationHelper
- FormationHelper.cs: pure offset calculator; Recalculate(count) rebuilds Vector3[] offsets; GetOffset(index) safe-returns zero if out of range
- MonsterData.cs: ScriptableObject; 8 SerializeField private fields + read-only properties; added _attackCooldown (default 1.5f); no enum — asset name is type ID
- MonsterDataGenerator.cs: Editor-only; creates 5 .asset files via MenuItem; skips existing
- ICombatant.cs: interface; CombatTeam enum {Ally,Enemy}; Team/Transform/IsAlive/DetectionRange + TakeDamage/OnTargetAssigned
- CombatSystem.cs: singleton; RegisterCombatant/UnregisterCombatant; ScanTargets() via InvokeRepeating(0.2s)
- Projectile.cs: pool-managed; Init(damage,target); Update-loop movement + sqrMagnitude hit + lifetime timeout
- ProjectilePool.cs: singleton pool; Prewarm N; Get(origin,damage,target)/Return(p); CreateFallbackPrefab() makes sphere if no prefab
- FlockUnitCombat.cs: companion combat component; ICombatant Ally; HP + attack cooldown in Update; Die() calls FlockManager.RemoveUnit
- MonsterBase.cs: abstract base; ICombatant Enemy; MonsterState enum; all state methods virtual; OnMonsterDied static event; MoveToward + FireProjectile helpers; PerformAttack() virtual hook called by UpdateAttack()
- MonsterA.cs: melee monster; only override is PerformAttack() — direct _currentTarget.TakeDamage(_data.AttackDamage); all patrol/chase/idle/death inherited
- MonsterB.cs: projectile monster; zigzag approach via sine-wave lateral offset; retreats after each shot; overrides Awake (cache sqr values), EnterChase (reset zigzag timer), UpdateChase (retreat + zigzag logic), PerformAttack (fire + retreat trigger)

## Next Session
- MonsterC (fast/swarmer) — inherit MonsterBase; override state methods for fast swarming behaviour
- MonsterC (fast/swarmer) — inherit MonsterBase; override state methods for swarming behaviour
- BossA (AoE ground slam), BossB (charge) — override EnterAttack + UpdateAttack
- TamingSystem.cs — subscribe to MonsterBase.OnMonsterDied, roll TamingChance, call FlockManager.Instance.AddUnit
- HitEffect.cs — hitstop, hitlag, camera shake, hit flash
- Inspector setup: add CombatSystem + ProjectilePool GameObjects; add FlockUnitCombat to FlockUnit GameObjects
