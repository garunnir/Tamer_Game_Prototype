# Predicted Problems

## MonsterB (2026-03-02)

| # | Problem | Mitigation |
|---|---------|------------|
| 1 | `_sqrAttackRange` is `private` in MonsterBase — MonsterB.UpdateChase() overrides the base entirely and needs it | Cache locally as `_mySqrAttackRange = _data.AttackRange * _data.AttackRange` in MonsterB.Awake() after base.Awake() |
| 2 | `_data` may be null at Awake if inspector not set — dereferencing `_data.AttackRange` would throw NullRef | Guard: `if (_data == null) return;` in MonsterB.Awake(), after calling base.Awake() (base already logs warning) |
| 3 | Zigzag amplitude ≥ attack range means monster circles target without ever entering attack range | Keep default amplitude (3f) well below attack range (4f); document in Inspector tooltip |
| 4 | PerformAttack() calls EnterChase() mid-UpdateAttack() — then UpdateAttack() continues to run `_attackTimer = _data.AttackCooldown` on a now-Chase state | Harmless: EnterAttack() always resets timer to 0 on re-entry; the cooldown assignment is a no-op |
| 5 | Retreat direction while target is moving — retreat point is calculated relative to current position, not world-fixed | Recalculate each frame (dynamic): `retreatPoint = transform.position - toTarget.normalized * retreatDistance * 2f`; monster always flees directly away |
| 6 | Zigzag timer not reset on EnterChase() — if monster re-enters Chase mid-wave, it continues mid-cycle, which is fine but start-of-cycle is cleaner | Reset `_zigzagTimer = 0f` in EnterChase() override |
